
// // import {
// //   Box,
// //   FormControl,
// //   FormControlLabel,
// //   Paper,
// //   Radio,
// //   RadioGroup,
// //   Stack,
// //   Switch,
// //   Typography,
// // } from "@mui/material";
// // import PaletteOutlinedIcon from "@mui/icons-material/PaletteOutlined";
// // import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";

// // const PreferenceSettings = ({ preferences, onChange }) => {
// //   const updatePreference = (key, value) => {
// //     onChange({ ...preferences, [key]: value });
// //   };

// //   return (
// //     <Paper
// //       elevation={0}
// //       sx={{
// //         p: { xs: 2, sm: 3 },
// //         mb: 3,
// //         border: "1px solid #E8E3DE",
// //         borderRadius: 3,
// //         bgcolor: "#FFFFFF",
// //       }}
// //     >
// //       <Stack direction="row" spacing={1.5} alignItems="center" mb={2}>
// //         <PaletteOutlinedIcon sx={{ color: "#A9744F", fontSize: 28 }} />
// //         <Box>
// //           <Typography fontWeight={700} color="#3F342C" fontSize={18}>
// //             Theme and preferences
// //           </Typography>
// //           <Typography variant="body2" color="#77716C">
// //             Customize your SyncSpace experience
// //           </Typography>
// //         </Box>
// //       </Stack>

// //       <Box sx={{ py: 2, borderBottom: "1px solid #F0EBE7" }}>
// //         <Typography fontWeight={600} color="#3F342C">
// //           Appearance
// //         </Typography>
// //         <Typography variant="body2" color="#77716C" mb={1}>
// //           Choose your preferred appearance for this settings page.
// //         </Typography>

// //         <FormControl>
// //           <RadioGroup
// //             row
// //             value={preferences.theme}
// //             onChange={(event) =>
// //               updatePreference("theme", event.target.value)
// //             }
// //           >
// //             <FormControlLabel
// //               value="light"
// //               control={<Radio sx={{ color: "#A9744F", "&.Mui-checked": { color: "#A9744F" } }} />}
// //               label="Light"
// //             />
// //             <FormControlLabel
// //               value="dark"
// //               control={<Radio sx={{ color: "#A9744F", "&.Mui-checked": { color: "#A9744F" } }} />}
// //               label="Dark"
// //             />
// //           </RadioGroup>
// //         </FormControl>
// //       </Box>

// //       <Stack direction="row" spacing={1.5} alignItems="center" mt={3} mb={1}>
// //         <NotificationsNoneOutlinedIcon sx={{ color: "#A9744F", fontSize: 27 }} />
// //         <Box>
// //           <Typography fontWeight={600} color="#3F342C">
// //             Notifications
// //           </Typography>
// //           <Typography variant="body2" color="#77716C">
// //             Choose which notification preferences to keep enabled.
// //           </Typography>
// //         </Box>
// //       </Stack>

// //       {[
// //         {
// //           key: "emailNotifications",
// //           title: "Email notifications",
// //           description: "Preference for receiving email updates.",
// //         },
// //         {
// //           key: "workspaceNotifications",
// //           title: "Workspace notifications",
// //           description: "Preference for workspace activity updates.",
// //         },
// //       ].map((item) => (
// //         <Box
// //           key={item.key}
// //           sx={{
// //             display: "flex",
// //             alignItems: "center",
// //             justifyContent: "space-between",
// //             gap: 2,
// //             py: 1.5,
// //             borderBottom: "1px solid #F0EBE7",
// //           }}
// //         >
// //           <Box>
// //             <Typography fontWeight={600} color="#3F342C">
// //               {item.title}
// //             </Typography>
// //             <Typography variant="body2" color="#77716C">
// //               {item.description}
// //             </Typography>
// //           </Box>

// //           <Switch
// //             checked={Boolean(preferences[item.key])}
// //             onChange={(event) =>
// //               updatePreference(item.key, event.target.checked)
// //             }
// //             sx={{
// //               "& .MuiSwitch-switchBase.Mui-checked": { color: "#A9744F" },
// //               "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
// //                 backgroundColor: "#A9744F",
// //               },
// //             }}
// //           />
// //         </Box>
// //       ))}

// //       <Typography variant="caption" color="#77716C" display="block" mt={2}>
// //         Preferences are saved in this browser. Notification switches store
// //         your choices; they do not send or suppress actual notifications unless
// //         notification delivery is connected to the backend.
// //       </Typography>
// //     </Paper>
// //   );
// // };

// // export default PreferenceSettings;

// import { useCallback, useEffect, useState } from "react";
// import {
//   Alert,
//   Box,
//   Button,
//   Snackbar,
//   Typography,
// } from "@mui/material";
// import RefreshOutlinedIcon from "@mui/icons-material/RefreshOutlined";

// import Navbar from "../components/common/Navbar.jsx";
// import Sidebar from "../components/common/Sidebar.jsx";

// import SettingsHeader from "../components/settings/SettingsHeader.jsx";
// import ProfileSettings from "../components/settings/ProfileSettings.jsx";
// import PreferenceSettings from "../components/settings/PreferenceSettings.jsx";
// import SecuritySettings from "../components/settings/SecuritySettings.jsx";
// import WorkspaceSettings from "../components/settings/WorkspaceSettings.jsx";

// import {
//   getCurrentUser,
//   getMyWorkspaces,
// } from "../api/settingsApi.js";

// const PREFERENCES_KEY = "syncspace-settings-preferences";

// const DEFAULT_PREFERENCES = {
//   theme: "light",
//   emailNotifications: true,
//   workspaceNotifications: true,
// };

// const readPreferences = () => {
//   try {
//     const saved = localStorage.getItem(PREFERENCES_KEY);

//     if (!saved) {
//       return DEFAULT_PREFERENCES;
//     }

//     const parsed = JSON.parse(saved);

//     return {
//       theme:
//         parsed.theme === "dark" || parsed.theme === "light"
//           ? parsed.theme
//           : "light",

//       emailNotifications:
//         typeof parsed.emailNotifications === "boolean"
//           ? parsed.emailNotifications
//           : true,

//       workspaceNotifications:
//         typeof parsed.workspaceNotifications === "boolean"
//           ? parsed.workspaceNotifications
//           : true,
//     };
//   } catch {
//     return DEFAULT_PREFERENCES;
//   }
// };

// const Settings = () => {
//   const [sidebarOpen, setSidebarOpen] = useState(true);

//   const [user, setUser] = useState(null);
//   const [workspaces, setWorkspaces] = useState([]);
//   const [workspaceId, setWorkspaceId] = useState("");

//   const [profileLoading, setProfileLoading] = useState(true);
//   const [workspaceLoading, setWorkspaceLoading] = useState(true);

//   const [profileError, setProfileError] = useState("");
//   const [workspaceError, setWorkspaceError] = useState("");

//   const [preferences, setPreferences] = useState(readPreferences);
//   const [noticeOpen, setNoticeOpen] = useState(false);

//   // --------------------------------------------------
//   // LOAD PROFILE
//   // --------------------------------------------------

//   const loadProfile = useCallback(async () => {
//     setProfileLoading(true);
//     setProfileError("");

//     try {
//       const result = await getCurrentUser();
//       setUser(result);
//     } catch (error) {
//       console.error("Failed to load profile:", error);

//       const status = error.response?.status;

//       if (status === 401) {
//         setProfileError(
//           "Your session may have expired. Please log in again."
//         );
//       } else if (status === 404) {
//         setProfileError("The profile endpoint was not found.");
//       } else if (!error.response) {
//         setProfileError(
//           "Cannot connect to the backend. Check that the server is running."
//         );
//       } else {
//         setProfileError(
//           error.response?.data?.message ||
//             "Unable to load your profile."
//         );
//       }
//     } finally {
//       setProfileLoading(false);
//     }
//   }, []);

//   // --------------------------------------------------
//   // LOAD WORKSPACES
//   // --------------------------------------------------

//   const loadWorkspaces = useCallback(async () => {
//     setWorkspaceLoading(true);
//     setWorkspaceError("");

//     try {
//       const result = await getMyWorkspaces();
//       const list = Array.isArray(result) ? result : [];

//       setWorkspaces(list);

//       setWorkspaceId((previousId) => {
//         if (list.some((item) => item._id === previousId)) {
//           return previousId;
//         }

//         return list[0]?._id || "";
//       });
//     } catch (error) {
//       console.error("Failed to load workspaces:", error);

//       const status = error.response?.status;

//       if (status === 401) {
//         setWorkspaceError(
//           "Please log in again to view your workspaces."
//         );
//       } else if (status === 404) {
//         setWorkspaceError(
//           "The workspace API endpoint was not found."
//         );
//       } else if (!error.response) {
//         setWorkspaceError(
//           "Cannot connect to the backend. Check that the server is running."
//         );
//       } else {
//         setWorkspaceError(
//           error.response?.data?.message ||
//             "Unable to load workspaces."
//         );
//       }

//       setWorkspaces([]);
//       setWorkspaceId("");
//     } finally {
//       setWorkspaceLoading(false);
//     }
//   }, []);

//   // --------------------------------------------------
//   // INITIAL LOAD
//   // --------------------------------------------------

//   useEffect(() => {
//     loadProfile();
//     loadWorkspaces();
//   }, [loadProfile, loadWorkspaces]);

//   // --------------------------------------------------
//   // PREFERENCES
//   // --------------------------------------------------

//   const handlePreferencesChange = (nextPreferences) => {
//     setPreferences(nextPreferences);

//     try {
//       localStorage.setItem(
//         PREFERENCES_KEY,
//         JSON.stringify(nextPreferences)
//       );

//       setNoticeOpen(true);
//     } catch (error) {
//       console.error(
//         "Unable to save preferences:",
//         error
//       );
//     }
//   };

//   // --------------------------------------------------
//   // REFRESH
//   // --------------------------------------------------

//   const refreshSettings = () => {
//     loadProfile();
//     loadWorkspaces();
//   };

//   // --------------------------------------------------
//   // UI
//   // --------------------------------------------------

//   return (
//     <Box
//       sx={{
//         minHeight: "100vh",
//         bgcolor: "#FAF8F6",
//       }}
//     >
//       {/* NAVBAR */}
//       <Navbar
//         onMenuClick={() =>
//           setSidebarOpen((previous) => !previous)
//         }
//       />

//       {/* SIDEBAR */}
//       <Sidebar open={sidebarOpen} />

//       {/* MAIN CONTENT */}
//       <Box
//         component="main"
//         sx={{
//           mt: "72px",

//           ml: {
//             xs: "72px",
//             md: sidebarOpen ? "256px" : "72px",
//           },

//           p: {
//             xs: 1.5,
//             sm: 2.5,
//             md: 3,
//           },

//           minHeight: "calc(100vh - 72px)",

//           transition: "margin-left 0.3s ease",
//         }}
//       >
//         <Box
//           sx={{
//             maxWidth: 1200,
//             mx: "auto",
//             width: "100%",
//           }}
//         >
//           {/* PAGE HEADER */}
//           <Box
//             sx={{
//               display: "flex",
//               justifyContent: "space-between",
//               alignItems: {
//                 xs: "flex-start",
//                 sm: "center",
//               },
//               flexWrap: "wrap",
//               gap: 1.5,
//               mb: 2,

//               "& .settings-title": {
//                 color: "#3F342C",
//               },

//               "& .settings-subtitle": {
//                 color: "#77716C",
//               },
//             }}
//           >
//             <SettingsHeader />

//             <Button
//               size="small"
//               variant="outlined"
//               startIcon={<RefreshOutlinedIcon />}
//               onClick={refreshSettings}
//               sx={{
//                 borderColor: "#A9744F",
//                 color: "#A9744F",
//                 textTransform: "none",
//                 borderRadius: 2,

//                 "&:hover": {
//                   borderColor: "#8B5E3C",
//                   bgcolor: "rgba(169,116,79,0.08)",
//                 },
//               }}
//             >
//               Refresh
//             </Button>
//           </Box>

//           {/* INFORMATION ALERT */}
//           <Alert
//             severity="info"
//             sx={{
//               mb: 3,

//               py: 0,

//               borderRadius: 2,

//               "& .MuiAlert-message": {
//                 py: 0.75,
//               },
//             }}
//           >
//             Profile and workspace details are loaded from your
//             backend. Notification preferences are saved in this
//             browser.
//           </Alert>

//           {/* ==================================================
//               SETTINGS CARDS GRID
//               ================================================== */}

//           <Box
//             sx={{
//               display: "grid",

//               /*
//                * One column on mobile
//                * Two columns on desktop
//                */
//               gridTemplateColumns: {
//                 xs: "1fr",
//                 md: "minmax(0, 1fr) minmax(0, 1fr)",
//               },

//               /*
//                * IMPORTANT:
//                * This creates a clearly visible 32px gap
//                * between left and right cards.
//                */
//               columnGap: {
//                 xs: 0,
//                 md: "32px",
//               },

//               /*
//                * Vertical space between rows.
//                */
//               rowGap: {
//                 xs: "24px",
//                 md: "32px",
//               },

//               width: "100%",

//               alignItems: "start",

//               /*
//                * Prevent cards from overflowing.
//                */
//               "& > *": {
//                 minWidth: 0,
//                 width: "100%",
//               },

//               /*
//                * Grid controls the spacing.
//                */
//               "& .MuiPaper-root": {
//                 marginBottom: "0 !important",
//               },
//             }}
//           >
//             {/* -----------------------------------------------
//                 CARD 1 - PROFILE
//                 ----------------------------------------------- */}
//             <Box sx={{ width: "100%" }}>
//               <ProfileSettings
//                 user={user}
//                 loading={profileLoading}
//                 error={profileError}
//               />
//             </Box>

//             {/* -----------------------------------------------
//                 CARD 2 - PREFERENCES
//                 ----------------------------------------------- */}
//             <Box sx={{ width: "100%" }}>
//               <PreferenceSettings
//                 preferences={preferences}
//                 onChange={handlePreferencesChange}
//               />
//             </Box>

//             {/* -----------------------------------------------
//                 CARD 3 - SECURITY
//                 ----------------------------------------------- */}
//             <Box sx={{ width: "100%" }}>
//               <SecuritySettings />
//             </Box>

//             {/* -----------------------------------------------
//                 CARD 4 - WORKSPACE
//                 ----------------------------------------------- */}
//             <Box sx={{ width: "100%" }}>
//               <WorkspaceSettings
//                 workspaces={workspaces}
//                 workspaceId={workspaceId}
//                 onWorkspaceChange={setWorkspaceId}
//                 loading={workspaceLoading}
//                 error={workspaceError}
//               />
//             </Box>
//           </Box>

//           {/* FOOTER */}
//           <Typography
//             variant="caption"
//             sx={{
//               display: "block",
//               textAlign: "center",
//               pt: 3,
//               color: "#77716C",
//             }}
//           >
//             SyncSpace · Account and workspace settings
//           </Typography>
//         </Box>
//       </Box>

//       {/* SAVE NOTIFICATION */}
//       <Snackbar
//         open={noticeOpen}
//         autoHideDuration={2500}
//         onClose={() => setNoticeOpen(false)}
//         message="Notification preferences saved in this browser."
//         anchorOrigin={{
//           vertical: "bottom",
//           horizontal: "center",
//         }}
//       />
//     </Box>
//   );
// };

// export default Settings;


import {
  Box,
  FormControl,
  FormControlLabel,
  Paper,
  Radio,
  RadioGroup,
  Stack,
  Switch,
  Typography,
} from "@mui/material";

import PaletteOutlinedIcon from "@mui/icons-material/PaletteOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";

const PreferenceSettings = ({
  preferences,
  onChange,
}) => {
  const updatePreference = (key, value) => {
    onChange({
      ...preferences,
      [key]: value,
    });
  };

  return (
    <Paper
      elevation={0}
      sx={{
        p: {
          xs: 2,
          sm: 3,
        },

        /*
         * IMPORTANT:
         * No bottom margin here.
         * Settings.jsx controls all card spacing.
         */
        mb: 0,

        border: "1px solid #E8E3DE",

        borderRadius: "14px",

        bgcolor: "#FFFFFF",

        /*
         * Subtle shadow makes this look
         * like a separate card.
         */
        boxShadow:
          "0 2px 8px rgba(63, 52, 44, 0.06)",

        boxSizing: "border-box",

        width: "100%",
      }}
    >
      {/* HEADER */}
      <Stack
        direction="row"
        spacing={1.5}
        alignItems="center"
        mb={2}
      >
        <PaletteOutlinedIcon
          sx={{
            color: "#A9744F",
            fontSize: 28,
          }}
        />

        <Box>
          <Typography
            fontWeight={700}
            color="#3F342C"
            fontSize={18}
          >
            Theme and preferences
          </Typography>

          <Typography
            variant="body2"
            color="#77716C"
          >
            Customize your SyncSpace experience
          </Typography>
        </Box>
      </Stack>

      {/* APPEARANCE */}
      <Box
        sx={{
          py: 2,
          borderBottom: "1px solid #F0EBE7",
        }}
      >
        <Typography
          fontWeight={600}
          color="#3F342C"
        >
          Appearance
        </Typography>

        <Typography
          variant="body2"
          color="#77716C"
          mb={1}
        >
          Choose your preferred appearance for this
          settings page.
        </Typography>

        <FormControl>
          <RadioGroup
            row
            value={preferences.theme || "light"}
            onChange={(event) =>
              updatePreference(
                "theme",
                event.target.value
              )
            }
          >
            <FormControlLabel
              value="light"
              control={
                <Radio
                  sx={{
                    color: "#A9744F",

                    "&.Mui-checked": {
                      color: "#A9744F",
                    },
                  }}
                />
              }
              label="Light"
            />

            <FormControlLabel
              value="dark"
              control={
                <Radio
                  sx={{
                    color: "#A9744F",

                    "&.Mui-checked": {
                      color: "#A9744F",
                    },
                  }}
                />
              }
              label="Dark"
            />
          </RadioGroup>
        </FormControl>
      </Box>

      {/* NOTIFICATIONS HEADER */}
      <Stack
        direction="row"
        spacing={1.5}
        alignItems="center"
        mt={3}
        mb={1}
      >
        <NotificationsNoneOutlinedIcon
          sx={{
            color: "#A9744F",
            fontSize: 27,
          }}
        />

        <Box>
          <Typography
            fontWeight={600}
            color="#3F342C"
          >
            Notifications
          </Typography>

          <Typography
            variant="body2"
            color="#77716C"
          >
            Choose which notification preferences to
            keep enabled.
          </Typography>
        </Box>
      </Stack>

      {/* NOTIFICATION OPTIONS */}
      {[
        {
          key: "emailNotifications",
          title: "Email notifications",
          description:
            "Preference for receiving email updates.",
        },
        {
          key: "workspaceNotifications",
          title: "Workspace notifications",
          description:
            "Preference for workspace activity updates.",
        },
      ].map((item) => (
        <Box
          key={item.key}
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 2,
            py: 1.5,
            borderBottom: "1px solid #F0EBE7",
          }}
        >
          <Box>
            <Typography
              fontWeight={600}
              color="#3F342C"
            >
              {item.title}
            </Typography>

            <Typography
              variant="body2"
              color="#77716C"
            >
              {item.description}
            </Typography>
          </Box>

          <Switch
            checked={Boolean(
              preferences[item.key]
            )}
            onChange={(event) =>
              updatePreference(
                item.key,
                event.target.checked
              )
            }
            sx={{
              "& .MuiSwitch-switchBase.Mui-checked": {
                color: "#A9744F",
              },

              "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                {
                  backgroundColor: "#A9744F",
                },
            }}
          />
        </Box>
      ))}

      {/* FOOTNOTE */}
      <Typography
        variant="caption"
        color="#77716C"
        display="block"
        mt={2}
      >
        Preferences are saved in this browser.
        Notification switches store your choices; they
        do not send or suppress actual notifications
        unless notification delivery is connected to
        the backend.
      </Typography>
    </Paper>
  );
};

export default PreferenceSettings;